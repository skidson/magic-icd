Thank you for your interest in the Actionscript3/Flex conversion of the zxing library.

The core folder contains the zxing library itself.
The zxing client folder contains a very basic client which will hopefully get you started.
There are some more comments in the zxing client project file.
Many improvements can be made and not all patches and updates have been applied to this conversion.
If you would like the help, feel free to join the zxing project and submit your improvements and bugfixes.
If you have questions, please send them to the zxing newsgroup.

Bas Vijfwinkel